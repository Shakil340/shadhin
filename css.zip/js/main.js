(function($) {
    "use strict";
    $(".serchbar i").click(function() {
        $(".serchbar input").toggle("slow")
    })

})(jQuery);